<html>
<head>
<title>Halaman Agenda</title>
<link rel="stylesheet" type="text/css" href="css/style2.css">
	<title>Admin</title>
</head>
<body background="logo.png">

	<table class="admin" border="2px">
		<tr>
			<td colspan="2" class="namaadmin">
				<h1 class="namaadmin">WELCOME ADMIN</h1>
			</td>
		</tr>
		<tr>
			<td bgcolor="" class="menuadmin">
				<a href="welcome.php">Home</a></input>
			</td>
			<td class="tengah2" rowspan="3" align="justify" >
<?php
include("koneksi.php");
$sql = "DELETE FROM agenda WHERE id_agenda = ".$_GET['id'];
mysql_query($sql) or exit("Error query : <b>".$sql."</b>.");
echo "<h2 align='center'>Data berhasil dihapus.</h2>";
?>
</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="berita_tampil.php">Berita</a>
			</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="agenda_tampil.php">Agenda</a>
			</td>
		</tr>
		</table>
		</body>
</html>