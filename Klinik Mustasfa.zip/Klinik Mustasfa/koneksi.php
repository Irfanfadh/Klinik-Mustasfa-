<?php
mysql_connect("localhost", "root", "")or exit("Gagal koneksi ke
database.");
mysql_select_db("puskesmas") or exit("Gagal Memilih Databa
	se");
?>