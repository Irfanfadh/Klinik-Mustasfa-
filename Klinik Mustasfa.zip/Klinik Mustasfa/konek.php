<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbase = "puskesmas";
mysql_connect($host, $user, $pass)or exit("Gagal koneksi ke
database.");
mysql_select_db($dbase) or exit("Gagal Memilih Database");
?>