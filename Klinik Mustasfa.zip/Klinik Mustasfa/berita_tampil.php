<html>
<head>
<title>Halaman Berita</title>
<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>
<table class="admin" border="2px">
		<tr>
			<td class="namaadmin" colspan="2">
				<h1 class="namaadmin">WELCOME ADMIN</h1>
			</td>
		</tr>
		<tr>
			<td class="menuadmin">
				<a href="welcome.php">Home</a></input>
			</td>
			<td class="tengah2" rowspan="3">
<h2>Daftar Berita</h2>
<p><a href="tambah_berita.php"><input type="button"/ value="Tambah Data"></a></p>
<table width="auto" border="1">
<tr style="background:#ccc">
<th width="auto">ID BERITA</th>
<th width="auto">JUDUL BERITA</th>
<th width="auto">TANGGAL UPLOAD</th>
<th width="auto">ISI BERITA</th>
<th width="auto">ID USER</th>
<th colspan="3" width="auto">AKSI</th>
</tr>
<?php
include("koneksi.php");
$sql = "SELECT id_berita,judul_berita,tanggal_upload,isi_berita,id_user FROM berita";
$hasil = mysql_query($sql) or exit("Error query: <b>".$sql."</b>.");
while($data = mysql_fetch_assoc($hasil)){
?>
<tr>
<td align="center"><?php echo $data['id_berita']; ?></td>
<td><?php echo $data['judul_berita']; ?></td>
<td><?php echo $data['tanggal_upload']; ?></td>
<td><?php echo $data['isi_berita']; ?></td>
<td><?php echo $data['id_user']; ?></td>
<td>
<a href="berita_ubah.php?id=<?php echo $data['id_berita']; ?>">
Ubah
</a>
</td>
<td>
<a href="berita_cek.php?id=<?php echo $data['id_berita']; ?>">
Lihat
</a>
</td>
<td>
<a href="hapus_berita.php?id=<?php echo $data['id_berita']; ?>">
Hapus
</a>
</td>
</tr>
<?php
}
?>
</table>
</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="berita_tampil.php">Berita</a>
			</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="agenda_tampil.php">Agenda</a>
			</td>
		</tr>
		</table>
</body>
</html>