<html>
<head>
<title>Halaman Agenda</title>
<link rel="stylesheet" type="text/css" href="css/style2.css">
	<title>Admin</title>
</head>
<body background="logo.png">

	<table class="admin" border="2px">
		<tr>
			<td class="namaadmin" colspan="2" >
				<h1 class="namaadmin">WELCOME ADMIN</h1>
			</td>
		</tr>
		<tr>
			<td bgcolor="" class="menuadmin">
				<a href="welcome.php">Home</a></input>
			</td>
			<td class="tengah2" rowspan="3" align="justify" >
			<h2 align="center">Detail Berita</h2>
<?php
include("koneksi.php");
$sql = "SELECT * FROM berita WHERE id_berita = ".$_GET['id'];
$hasil = mysql_query($sql);
$data = mysql_fetch_assoc($hasil);
echo "ID BERITA : ".$data['id_berita'];
echo "<br /><br />";
echo "JUDUL BERITA : ".$data['judul_berita'];
echo "<br /><br />";
echo "TANGGAL UPLOAD : ".$data['tanggal_upload'];
echo "<br /><br />";
echo "ISI BERITA : ".$data['isi_berita'];
echo "<br /><br />";
echo "ID USER : ".$data['id_user'];
?>
</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="berita_tampil.php">Berita</a>
			</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="agenda_tampil.php">Agenda</a>
			</td>
		</tr>
		</table>
		</body>
</html>