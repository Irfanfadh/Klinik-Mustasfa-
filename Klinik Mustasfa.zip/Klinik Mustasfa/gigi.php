<!DOCTYPE html>
<html>
<head>
  <title>Puskesmas Kita</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
          <!--bagian header logo dan search-->
<div class="row sisi">
  <div class="col-md-4 logo">
   
      <span class="logos">
      <img src="img/logo.png"/>
       </span>
       <!--login-->
      <span class="login">
         <form action="login.php" method="post">
         <table cellpadding="5px" bgcolor="#ccc">
         <tr>
         <td class="nm">
Username : </td>
<td><input class="nma" type="text" name="txtUsername"/></td>
</tr>
<tr>
<td class="nm">Password : </td>
<td><input class="nma" type="password" name="txtPassword"/>
</td></tr>
<tr><td ></td>
<td><input class="kirim" type="submit" value="Login" />
</td></tr>
</table>
</form>
      </span>
      <!--end login-->
      
  </div>
</div>

                <!--slider-->
<div col-md-12 class="slide">
  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
    <li data-target="#carousel-example-generic" data-slide-to="4"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="img/tunggu.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>ruang tunggu</p>
        <p>Ruang tunngu yang nyaman dan dilengkapi fasiitas TV LCD yang menyiarkan berita seputar kesehatan dan tips tips kesehatan sehingga pasien mendapatkan informasi seputar kesehatan</p>
      </div>
    </div>
    <div class="item">
      <img src="img/parkiran.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>lapangan parkir yang luas</p>
        <p>lapangan parkir yang disediakan puskesmas tidak hanya cukup untuk motor tetapi juga mobil serta dilengkapi fasilitas gazebo untuk tempat menunggu pengantar pasien</p>
      </div>
    </div>
     <div class="item">
      <img src="img/pelayanan.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>pelayanan ramah</p>
        <p>pelayanan kami yang ramah membuat pasien merasa nyaman dan termotivasi untuk kembali sehat dan dapat menenangkan pasien selama masa perawatan</p>
      </div>
    </div>
    <div class="item">
      <img src="img/usg.png" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>fasilitas kehamilan</p>
        <p>pengecekkan kandungan sudah menggunakan USG 4 Dimensi yang sudah memungkinkan ibu hamil melihat kondisi bayinya secara jelas</p>
      </div>
    </div>
    <div class="item">
      <img src="img/masjid.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>tempat ibadah</p>
        <p>Puskesmas Kita juga dilengkapi dengan mushola yang nyaman dan bersih, alat sholat yang rutin dibersihkan sehingga membuat pasien yang ingin beribadah jadi nyaman dan tidak khawatir dengan kebersihannya</p>
      </div>
    </div>
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
          <!--menu-->
          <div class="menu navbar navbar-inverse">
            <div class="container">
              <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
          </div>
          <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li><a href="index.php">HOME</a></li>
            <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">PROFILE</a>
          <ul class="dropdown-menu turun">
            <li><a class="tulis" href="visimisi.php">Visi-Misi</a></li>
            <li><a href="sambutan.php">Sambutan</a></li>
          </ul>
        </li>
            <li><a target="_blank" href="dokter.php">DATA DOKTER</a></li>
            <li><a target="_blank" href="pegawai.php">DATA PEGAWAI</a></li>
             <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">INFORMASI</a>
          <ul class="dropdown-menu turun">
            <li><a href="layanan.php" target="_blank">Pelayanan</a></li>
            <li><a href="agenda.php" target="_blank">Agenda</a></li>
          </ul>
        </li>
            </ul>
          </div>
          </div>
</div>
<!--end menu-->

<!--tanda-->
  <div>
    <table class="tanda">
      <tr>
       <td class="tanda2"><a href="layanan.php">Pelayanan</a></td>
      </tr>
    </table>
  </div>
<?php
  include('konek.php');
$jadwal = mysql_query("SELECT nama_jadwal,hari_jadwal,jam_jadwal,deskripsi_jadwal FROM jadwal WHERE
id_jadwal=1");
$tarif = mysql_query("SELECT nama_tarif,harga_tarif FROM tarif WHERE id_kategori_tarif=2");
$no=1;
//$hasiljadwal = mysql_query($jadwal);
//$hasiltarif = mysql_query($tarif);
$datajadwal = mysql_fetch_assoc($jadwal);
//$datatarif = mysql_fetch_assoc($hasiltarif);
?>
      <!--bagian berita/menu utama-->
    <table class="tabel">
      <tr>
      <td class="layanan">

        <?php
        echo "<h3 class='tarif'>".$datajadwal['nama_jadwal']."</h3>";
        echo "<p class='tarif'>Hari :".$datajadwal['hari_jadwal']."</p>";
        echo "<p class='tarif'>Jam :".$datajadwal['jam_jadwal']."</p>";
        echo "<p class='tarif'>".$datajadwal['deskripsi_jadwal']."</p>";
        echo '<h4 class="tarif">Daftar Pelayanan Umum</h4></td>';
        echo '<tr>';
        echo '<td class="tarif1">
<table width="600px" border="1" >
<tr style="background: #00ff00">
<th width="5%">No</th>
<th width="50%">Nama Layanan</th>
<th width="35%">Tarif</th>
</td>
</tr>';

while($datatarif = mysql_fetch_array($tarif))
 {
echo "
 <td>".$no."</td>
 <td>".$datatarif['nama_tarif']."</td>
 <td>".$datatarif['harga_tarif']."</td>
 </tr>";
 $no++;
 }
echo '</table>';
        ?>    
        </td>
        </tr>
    </table>
    <div class="footer">
        <p>Ring Road Utara KM 10</br>
        Condong Catur, Sleman</br>
        D.I. Yogyakarta</br>
        (0274)446756/662819</p>
     </div>
 
  <!--Pemanggilan Java Script-->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.js"></script>
</body>
</html>