<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Admin</title>
</head>
<body background="logo.png">

	<table class="admin" border="2px">
		<tr>
			<td colspan="2">
				<h1 class="namaadmin">WELCOME ADMIN</h1>
			</td>
		</tr>
		<tr class="admin2">
			<td class="menuadmin">
				<a href="welcome.php">Home</a></input>
			</td>
			<td rowspan="3">
				
			</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="agenda_tampil.php">Berita</a>
			</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="agenda_tampil.php">Agenda</a>
			</td>
		</tr>
		</table>
		

</body>
</html>