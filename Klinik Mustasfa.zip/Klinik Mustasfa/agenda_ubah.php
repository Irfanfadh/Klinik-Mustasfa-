<?php
include("koneksi.php");
$sql = "SELECT id_agenda,nama_agenda,tanggal_hari,jam_agenda,tempat_agenda,deskripsi_agenda,id_user FROM agenda WHERE id_agenda = ".$_GET['id'];
//$sql.= "WHERE berita_id = ".$_GET['id'];
$hasil = mysql_query($sql) or exit("Error query : <b>".$sql."</b>.");
$data = mysql_fetch_assoc($hasil);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Agenda</title>
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>

	<table class="admin" border="2px">
		<tr>
			<td class="namaadmin" colspan="2">
				<h1 class="namaadmin">WELCOME ADMIN</h1>
			</td>
		</tr>
		<tr>
			<td class="menuadmin">
				<a href="welcome.php">Home</a></input>
			</td>
			<td align="justify" class="tengah2" rowspan="3">
<fieldset>
<h2>Update Agenda</h2>
<form method="post" action="control_ubah_agenda.php">
	<table width="auto" cellpadding="2" cellspacing="2">
	<tr>
			<td width="auto">
				ID Agenda</td>
				<td> : <input type="text" name="txtID" value="<?php echo $data['id_agenda'];?>"></input>
			</td>
		</tr>
		<tr>
			<td width="auto">
				Nama Agenda : &nbsp;</td>
				<td> : <input type="text" name="txtNAMA" value="<?php echo $data['nama_agenda'];?>"></input>
			</td>
		</tr>
		<tr>
		<td width="auto">Hari dan Tanggal Agenda</td>
			<td> : <input type="text" name="txtTANGGAL" value="<?php echo $data['tanggal_hari'];?>"></input></td>
		</tr>
		<tr>
		<td width="auto">Jam Agenda</td>
			<td> : <input type="text" name="txtJAM" value="<?php echo $data['jam_agenda'];?>"></textarea></td>
		</tr>
		<tr>
		<td width="auto">Tempat Agenda</td>
			<td> : <input type="text" name="txtTEMPAT" value="<?php echo $data['tempat_agenda'];?>"></input></td>
		</tr>
		<tr>
		<td width="auto">Deskripsi Agenda</td>
			<td> : <textarea type="text" name="txtISI" value="<?php echo $data['deskripsi_agenda'];?>"></textarea></td>
		</tr>
		<tr>
			<td colspan="2">
				<input type="hidden" name="txtid" value="<?php echo $data['id_agenda'];?>" />
				<input type="submit" value="Submit" />
			</td>
		</tr>
	</table>
</form>
</fieldset>

			</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="berita_tampil.php">Berita</a>
			</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="agenda_tampil.php">Agenda</a>
			</td>
		</tr>
		</table>

</body>
</html>