-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2017 at 12:02 PM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `puskesmas`
--

-- --------------------------------------------------------

--
-- Table structure for table `agenda`
--

CREATE TABLE `agenda` (
  `id_agenda` int(11) NOT NULL,
  `nama_agenda` varchar(50) NOT NULL,
  `tanggal_hari` varchar(20) NOT NULL,
  `jam_agenda` varchar(20) NOT NULL,
  `tempat_agenda` varchar(30) NOT NULL,
  `deskripsi_agenda` text NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agenda`
--

INSERT INTO `agenda` (`id_agenda`, `nama_agenda`, `tanggal_hari`, `jam_agenda`, `tempat_agenda`, `deskripsi_agenda`, `id_user`) VALUES
(1, 'Penyuluhan DM (Diabetes Melitus)', 'Selasa, 31 Mei 2016', '09.00 WIB - selesai ', 'di Aula Balai Desa', 'Acara ini kami buat karena rasa simpati kami kepada para penderita diabetes melitus. Acara ini dihadiri oleh peserta penderita dm (diabetes melitus) wilayah puskesmas KIta dengan narasumber dari Dr. Amelia Widya Astuti, Sp.PD dan Dr. Priska Amalia, Sp.U. Dalam acara ini disamping akan dijelaskan mengenai penyakit diabetes melitus, nantinya juga akan dibentuk tim peserta senam dm (diabetes melitus) yang nantinya akan dilaksanakan senam dm (diabetes melitus) secara rutin.</p>', 1),
(2, 'Posyandu Balita Gratis', 'Sabtu, 04 Juni 2016', '09.00 - 11.00 WIB', 'Puskesmas Kita', '<p align="justify">Acara ini merupakan suatu program bulanan dari puskesmas KIta, karena kami sadar akan betapa pentingnya kegiatan posyandu pada anak. Karena kami mengamati di beberapa daerah yang memiliki masalah anak termasuk penyakit-penyakit yang berbahaya hingga kasus kematian pada anak (balita). Dalam acara ini juga akan ada seperti demo atau sosialisasi tentang merawat anak dengan baik, dan juga akan diberikan vitamin gratis untuk anak. Acara ini gratis tanpa dipungut biaya, dan acara ini juga khusus untuk warga masyarakat di wilayah puskesmas KITA. Syaratnya hanya membawa Kartu Keluarga saja.</p>', 1),
(3, 'Sunat Masal Gartis', 'Minggu, 12 Juni 2016', '08.30 - 14.00 WIB', 'Puskesmas KITA', '<p align="justify">Acara ini kami selenggarakan khusus untuk warga masyarakat wilayah sekitar Puskesmas KITA. Melihat akan pentingnya sunat bagi kesehatan organ kelamin, maka kami tergugah untuk mengadakan acara ini, pada acara ini juga akan diberikan doorprize atau hadiah bagi anak yang mau ikut sunat ini, hal itu kami lakukan untuk menarik hati para anak. Acara ini didukung oleh beberapa sponsor ternama dan dari dinas kesehatan.</p>', 1),
(4, 'Pemeriksaan Gratis dan Pengobatan Gratis', 'Sabtu, 18 Juni 2016', '08.30 - 11.00 WIB', 'Puskesmas KITA', 'Acara ini kami selenggarakan bagi seluruh warga masayarakat wilayah Puskesmas KITA. Acara ini merupakan sebagai tanda peduli puskesmas KITa terhadap kesehatan warga masyarakat, karena sebagian besar warga masyarakat berasal dari keluarga menengah ke bawah. Untuk dapat mengikuti acara ini warga wajib membawa KTP atau Kartu Keluarga.</p>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id_berita` int(11) NOT NULL,
  `judul_berita` varchar(100) NOT NULL,
  `tanggal_upload` date NOT NULL,
  `isi_berita` text NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id_berita`, `judul_berita`, `tanggal_upload`, `isi_berita`, `id_user`) VALUES
(1, 'Hindari Jenis-jenis Makanan Ini Jika Kadar Trigliserida Anda Sedang Tinggi', '2016-05-11', '<p align="justify"><b>TRIBUNNEWS.COM, JAKARTA---</b> Trigliserida merupakan jenis lemak darah yang sebenarnya digunakan untuk memberikan energi. Namun, jika kadarnya terlalu tinggi bisa meningkatkan risiko penyakit jantung dan stroke.\r\nKadar trigliserida yang dinyatakan sehat adalah di bawah 150 mg/dL, sementara 150-199 mg/dL harap berhati-hati, dan 200-499 mg/dL termasuk tidak sehat. Di atas 499 mg/dL sangat tidak sehat.\r\nKadar trigliserida tinggi jangan diremehkan. Pada banyak kasus, dokter akan meresepkan obat-obatan untuk menurunkannya, selain juga perubahan pola makan dan gaya hidup.\r\nTerkait dengan pola makan, tak dipungkiri ada beberapa jenis makanan yang berpengaruh langsung pada level trigliserida, terutama yang mengandung karbohidrat tinggi.\r\nBerikut adalah beberapa jenis makanan yang harus dihindari untuk menjaga kadar trigliserida bisa diturunkan atau normal.\r\n</p>\r\n\r\n<ol>\r\n<li><b>Minuman manis</b></li>\r\n<p align="justify">Minuman mengandung gula, seperti es teh, soda, jus buah, dan sebagainya, akan membuat tubuh Anda dibanjiri kelebihan gula. Paling tidak batasi mengonsumsi minuman manis untuk menurunkan kadar trigliserida.</p>\r\n\r\n<li><b>Makanan bertepung</b></li>\r\n<p align="justify">Makanan yang mengandung tepung, seperti kentang, pasta, atau nasi, meruapkan sumber energi yang baik. Tetapi, makanan sehat ini akan dipecah menjadi gula saat masuk dalam sistem pencernaan. Kelebihan gula merupakan salah satu penyebab kadar trigliserida menjadi tinggi.</p>\r\n\r\n<li><b>Kelapa</b></li>\r\n<p align="justify">Manfaat sehat kelapa sudah dikenal di seluruh dunia, teapi kelapa juga mengandung lemak jenuh. Kita memang tak perlu menghindari sama sekali makanan mengandung santan, tetapi batasi saja sampai kadar trigliserida terkontrol.</p>\r\n\r\n<li><b>Madu atau sirup maple</b></li>\r\n<p align="justify">Tak perlu dijelaskan lagi, madu atau sirup maple mengandung gula yang tinggi. Jika kadar trigliserida Anda tinggi, batasi asupan kedua jenis pemanis ini.</p>\r\n\r\n<li><b>Lemak jenuh</b></li>\r\n<p align="justify">Produk susu berlemak tinggi, butter, daging merah, dan sebagainya, merupakan makanan mengandung lemak jenuh yang bisa meningkatkan kadar trigliserida. Mengurangi makanan jenis ini juga bisa membuat level Kolesterol terjaga.</p>\r\n\r\n<li><b>Alkohol</b></li>\r\n<p align="justify">Kadar trigliserida tinggi adalah alasan lain untuk menjauhi alkohol.</p>\r\n\r\n<li><b>Makanan yang dipanggang</b></li>\r\n<p align="justify">Kadar trigliserida yang tinggi diketahui dipicu oleh asupan makanan yang dipanggang, seperti roti dan sejenisnya. Biasanya makanan tersebut mengandung lemak jenuh yang juga tinggi.</p>\r\n</ol><br/>\r\n<p>Sumber : BOLDSKY</p><br/>\r\n<p>Referensi</p><br/>\r\n<a href="http://www.tribunnews.com/kesehatan/2016/05/11/hindari-jenis-jenis-makanan-ini-jika-kadar-trigliserida-anda-sedang-tinggi">http://www.tribunnews.com/kesehatan/2016/05/11/hindari-jenis-jenis-makanan-ini-jika-kadar-trigliserida-anda-sedang-tinggi</a>', 1),
(2, 'Beberapa Hal Ini Bikin Daya Tahan Tubuh Lemah', '2016-05-08', '<h2></h2>\r\n<p align="justify"><b>TRIBUNJOGJA.COM - </b>Apakah yang mampu menghentikan infeksi patogen dari luar merusak sel-sel tubuh? Hanya sistem kekebalan tubuh yang bisa melakukannya. Tanpa sistem imun yang baik, tubuh kita tak akan bisa bertahan sampai sekarang.\r\nMeski begitu, seiring dengan pertambahan usia dan gaya hidup, sistem kekebalan tubuh bisa menjadi lemah dan lelah. Ketika "tentara" di tubuh kita lemah, maka tugasnya untuk melindungi kita tak bisa dilakukan.</p>\r\n\r\n<p align="justify">Dengan mengenali faktor-faktor apa yang membuat daya tahan tubuh rendah, kita bisa melakukan banyak hal untuk membuatnya tetap kuat.\r\nBerikut ini adalah beberapa faktor yang bisa membuat sistem imun lemah.</p>\r\n<ul>\r\n<li><b>Terlalu banyak bepergian</b></li>\r\n<p align="justify">Melancong memang menyenangkan, tapi, ke mana pun Anda pergi, terutama ke tempat baru, sistem kekebalan tubuh kita bekerja lebih keras untuk melindungi kita dari kuman dan infeksi. Hal ini akan membuat sel imun lemah. Selain itu, makanan baru dan lingkungan juga menjadi ancaman baru.</p>\r\n\r\n<li><b>Obat antasida</b></li>\r\n<p align="justify">Obat ini adalah obat bebas yang digunakan untuk meredakan peningkatan asam lambung. Meski begitu, pemakaian antasida dalam jangka panjang bisa melemahkan kekebalan tubuh.</p>\r\n\r\n<li><b>Minuman keras</b></li>\r\n<p align="justify">Tahukah Anda, alkohol bisa memperlambat produksi sel darah merah. Tentu kebiasaan minum ini juga membuat sel imun lemah.</p>\r\n\r\n<li><b>Kesepian</b></li>\r\n<p align="justify">Orang yang kesepian cenderung memiliki daya tahan tubuh lebih rendah dibanding orang yang memiliki dukungan sosial lebih besar. Ya, kehidupan sosial memang penting bagi kesehatan.</p>\r\n\r\n<li><b>Diet ketat</b></li>\r\n<p align="justify">diet ketat akan membuat kita kekurangan nutrisi yang diperlukan tubuh. Sudah tentu hal ini membuat daya tahan tubuh menurun.</p>\r\n\r\n<li><b>Antibiotik</b></li>\r\n<p align="justify">Beberapa gangguan penyakit membuat kita harus mengonsumsi antibiotik. Faktanya, hal ini secara bertahan akan menurunkan daya tahan tubuh.</p>\r\n\r\n<li><b>Kurang tidur</b></li>\r\n<p align="justify">Ini adalah gaya hidup utama yang bisa merusak kekebalan tubuh. Jangan biasakan kurang tidur jika Anda ingin selalu sehat.</p></ul>\r\n\r\n<p align="justify">Referensi : <a href="http://jogja.tribunnews.com/2016/05/04/beberapa-hal-ini-bikin-daya-tahan-tubuh-lemah">http://jogja.tribunnews.com/2016/05/04/beberapa-hal-ini-bikin-daya-tahan-tubuh-lemah</a></p>\r\n', 1),
(3, 'Jangan Abaikan 6 Jenis Sakit Kepala Ini, Segeralah ke Dokter Jika Mengalaminya', '2016-05-06', '<p align="justify"><b>TRIBUNJOGJA.COM - </b>Jika sakit kepala sudah mengganggu kehidupan Anda dan menyebabkan rasa sakit kronis, jangan enggan untuk segera mendapatkan bantuan medis.\r\nBerikut beberapa gejala sakit kepala yang sebaiknya ditangani oleh dokter :\r\n</p>\r\n\r\n<ol>\r\n<li>Apapun jenis sakit kepala yang Anda alami, baik karena tegang, sakit kepala migrain, atau sakit kepala cluster, Anda perlu memeriksakan ke dokter bila obat biasa sudah tak ampuh lagi, sehingga Anda mengambil dosis yang lebih tinggi. Bertujuan untuk menghindari efek samping, seperti perdarahan atau kerusakan hati, jika dikonsumsi dalam dosis tinggi atau terlalu sering.</li>\r\n\r\n<li>Rasa sakit kepala membuat Anda kesulitan melakukan aktivitas sehari-hari, seperti kesulitan berjalan, membuat Anda tak nafsu makan, hilang konsentrasi selama lebih dari 2 hari.</li>\r\n\r\n<li>Sakit kepala semakin buruk dari waktu ke waktu. Dokter dapat meresepkan obat berbeda untuk mengontrol sakit kepala sesuai pemicunya, bahkan untuk mencegah rasa sakit itu datang kembali.</li>\r\n\r\n<li>Sakit kepala Anda yang berkaitan dengan kondisi neurologis lain seperti kejang. Ditakutkan pasien mengalami pendarahan dalam otak yang disebabkan oleh pecahnya pembuluh darah.</li>\r\n\r\n<li>Sakit kepala berkaitan dengan kelemahan otot atau mati rasa di anggota tubuh, perubahan sikap, perubahan kemampuan bicara, atau perubahan penglihatan. Ini bisa menjadi tanda stroke atau tumor otak dan harus diperiksa oleh seorang profesional medis.</li>\r\n\r\n<li>Sakit kepala yang timbul setelah terjadi benturan atau pukulan.</li>\r\n</ol>\r\n\r\n<p align="justify">Referensi : <a href="http://jogja.tribunnews.com/2016/05/01/jangan-abaikan-6-jenis-sakit-kepala-ini-segeralah-ke-dokter-jika-mengalaminya">http://jogja.tribunnews.com/2016/05/01/jangan-abaikan-6-jenis-sakit-kepala-ini-segeralah-ke-dokter-jika-mengalaminya</a></p>', 1),
(4, 'Menristek: Penanganan DBD Bukan Membunuh Nyamuk Aedes Aegypti', '2016-05-04', '<p align="justify"><b>Laporan Reporter Tribun Jogja, Kurniatul Hidayah\r\nTRIBUNJOGJA.COM, SLEMAN -</b>Menteri Riset, Teknologi dan Pendidikan Tinggi, Muhammad Nasir menyatakan bahwa sistem pengendalian Demam Berdarah Dengue (DBD) yang dilakukan oleh Eliminate Dengue Project (EDP-Yogya), menjadi solusi yang luar biasa untuk kasus DBD di Indonesia.</p>\r\n\r\n<p align="justify">Saat ini, jelasnya, Indonesia menduduki peringkat ke dua kasus DBD di seluruh dunia, serta hingga kini belum ditemukan obat untuk penyakit DBD. "Kalau bicara tentang cost yang dikeluarkan pemerintah dalam menangani DBD, costnya luar biasa besar. Itu karena sampai sekarang belum ada obatnya. Selama ini yang dilakukan adalah meningkatkan ketahanan tubuh dengan cara meningkatkan produksi cairan dalam tubuh pasien DBD agar memiliki kekebalan yang makin tinggi," jelasnya ketika melakukan peninjauan ke Kantor Penelitian EDP-Yogya,.</p>\r\n\r\n<p align="justify">EDP-Yogya melakukan penelitian dengan menggunakan bakteri Wolbachia dalam tubuh nyamuk Aedes aegypti, yang menyebabkan virus Dengue tidak dapat berkembang dalam tubuh nyamuk, sehingga nyamuk tidak dapat menularkan penyakit demam berdarah dengue. Bila nyamuk betina ber-wolbachia kawin dengan nyamuk jantan lain non Wolbachia, maka akan menghasilkan keturunan nyamuk ber-wolbachia.</p>\r\n\r\n<p align="justify">Sebaliknya apabila nyamuk jantan ber-wolbachia kawin dengan nyamuk nonwolbachia maka telurnya tidak akan bisa menetas. "Saya sangat berterima kasih kepada UGM yang telah melakukan riset di bidang penanganan demam berdarah. Di mana penanganan DBD bukan dengan penyemprotan dan pembunuhan nyamuk Aedes aegypti, tapi dengan melakukan pemandulan dan membawa satu bakteri yang mematikan DBD," imbuh Nasir.</p>\r\n\r\n<p align="justify">Selanjutnya, Nasir berencana bertemu dengan MenteriKesehatan RI, Nila Farid Moeloek, untuk memanfaatkan hasil riset tersebut, guna menekan jumlah kasus DBD yang terjadi di skala nasional. "Kalau bisa dalam minggu ini bertemu dengan Bu Menkes, karena ini sangat penting. Kalau bisa, nanti akan dilakukan pengembangan ke depan secara masif," tegasnya.(tribunjogja.com)</p>\r\n\r\n<p align="justify">Referensi : <a href="http://jogja.tribunnews.com/2016/04/26/menristek-penanganan-dbd-bukan-membunuh-nyamuk-aedes-aegypti">http://jogja.tribunnews.com/2016/04/26/menristek-penanganan-dbd-bukan-membunuh-nyamuk-aedes-aegypti</a>\r\n', 1),
(5, 'Penderita Diabetes Tak Selalu Harus Berpantang Makanan', '2016-05-03', '<p align="justify"><b>TRIBUNNEWS.COM -</b>Vonis diabetes kerap memupus asa untuk menyantap makanan enak. Berbagai jenis makanan terpaksa dianggap musuh. Misalnya, menjauhi gula karena dianggap sebagai pemicu diabetes. Tapi, tak semua itu benar. Berikut fakta dan mitos mengenai pola makan bagi para pengidap diabetes :</p>\r\n<ul>\r\n<li>Gula adalah penyebab diabetes</li>\r\n<p align="justify">Ini adalah mitos. Gula bukan penyebab nomor satu diabetes.diabetes terjadi ketika tubuh tak cukup menghasilkan insulin atau tak bisa menggunakan insulin yang ada dengan benar. Yang harus diawasi sebenarnya bukan gula, tapi total kalori yang diasup.</p>\r\n\r\n<li>Banyak pantangan makan</li>\r\n<p align="justify">Ini mitos. Pengidap diabetes tetap bisa menyantap berbagai jenis makanan asal kadar gula darah terjaga di batas normal. Sebaiknya, rencanakan menu makan agar sesuai dengan aktifitas dan obat yang digunakan.</p>\r\n\r\n<li>Tak boleh menyantap karbohidrat</li>\r\n<p align="justify">Ini jelas mitos. Tubuh perlu karbohidrat. Karbohidrat wajib masuk dalam menu makan, baik Anda memiliki diabetes atau tidak.\r\nBahkan beberapa jenis sumber karbohidrat memiliki kandungan vitamin, serat, dan mineral. Memang ada beberapa sumber karbohidrat yang sebaiknya dihindari, tapi pengidap diabetestetap bisa merasakan nikmatnya karbohidrat. Asalkan asupannya dihitung seksama karena karbohidrat memengaruhi kadar gula darah.\r\n</p>\r\n\r\n<li>Protein sahabat pengidap diabetes</li>\r\n<p align="justify">Satu lagi mitos yang harus diluruskan. Kalau karbohidrat adalah musuh, protein adalah sahabat. Padahal tak selalu demikian. Kalau protein itu disantap bersama lemak yang terlalu banyak, justru memiliki potensi mengancam jantung. Jadi sebaiknya konsultasikan dengan dokter mengenai jenis protein yang aman disantap.</p>\r\n\r\n<li>Obat bikin pengidap diabetes bebas makan tanpa aturan</li>\r\n<p align="justify">Ini mitos. Ada anggapan kalau menambah takaran insulin atau obat jenis lain bisa menurunkan lonjakan kadar gula darah akibat pola makan sembarangan. Hal ini perlu diluruskan, menambah takaran tanpa hitungan itu bukan kartu bebas makan tanpa aturan.\r\nPengidap diabetes tetap harus menakar menu makan meski sudah menggunakan insulin atau obat lain untuk menstabilkan gula darah. Menambah dosis obat tanpa saran ahli medis untuk menutupi ‘dosa’ makan sembarangan sangat tidak dianjurkan.\r\n</p>\r\n\r\n<li>Selamat tinggal makanan favorit</li>\r\n<p align="justify">Satu lagi mitos. Pengidap diabetes tetap bisa menyantap makanan kesukaan selama ada aturannya. Misalnya, mengubah cara masak dari digoreng menjadi dipanggang. Bisa juga dengan memperkecil porsi, yang jelas lebih baik daripada tidak sama sekali.</p>\r\n\r\n<liMakanan penutup adalah musuh</li>\r\n<p align="justify">Jelas ini mitos. Siapa yang tak suka es krim? Menyantapnya sebagai hidangan pencuci mulut merupakan kenikmatan tersendiri. Pengidap diabetes tetap bisa menikmati makanan penutup seperti es krim atau pie asal porsinya dikurangi. Buah-buahan, kue gandum, atau yogurt bisa jadi alternatif makanan penutup.</p>\r\n\r\n<li>Wajib makan menu khusus diabetes</li>\r\n<p align="justify">Ini juga mitos. Tak ada perubahan pada menu pengidap diabetes. Apalagi sampai wajib mengkonsumsi menu khusus. Yang harus diperhatikan adalah kalori, jenis dan jumlah karbohidrat, lemak, serta protein.</p>\r\n\r\n<li>Pengidap diabetes tak boleh ngemil</li>\r\n<p align="justify">Ini jelas mitos. Ngemil dianggap membuat kadar gula darah melonjak. Padahal cemilan bisa berfungsi menjaga gula darah tetap stabil. Dengan catatan, tak asal ngemil. Harus diperhatikan jumlah kalori yang masuk.</p>\r\n</ul><br/>\r\n\r\n<p>Penulis: Michael Metekohy</p>\r\n<p align="justify">Referensi : <a href="http://www.tribunnews.com/kesehatan/2016/05/14/penderita-diabetes-tak-selalu-harus-berpantang-makanan">http://www.tribunnews.com/kesehatan/2016/05/14/penderita-diabetes-tak-selalu-harus-berpantang-makanan</a></p>', 1),
(6, 'Hasil Studi: Bangun Pagi Meningkatkan Kualitas Kesehatan', '2016-05-01', '<p align="justify"><b>TRIBUNNEWS.COM -</b> Beberapa orang benci bangun pagi dan memilih untuk bangun lebih siang.Namun, ada baiknya untuk menghilangkan prilaku itu dan mengubahnya sekarang juga.Pasalnya, bangun pagi terbukti mampu meningkatkan kesehatan."Bangun pagi membuat manusia lebih konsisten dengan siklus jam biologisnya," kata Alcibiades J Rodriguez MD, asisten profesor, Departemen Neurologi, NYU Langone Comprehensive Epilepsy Center-Sleep Center."Sinar matahari adalah stimulan paling kuat dalam memberi energi dan meningkatkan mood Anda, sehingga Anda bisa memulai aktivitas dengan tubuh Anda lebih segar."Bangun lebih awal mungkin tidak langsung menyebabkan adanya perbaikan kesehatan, tapi dapat membantu orang beradaptasi pada kebiasaan sehat yang dapat membantu meningkatkan kehidupan mereka secara keseluruhan."Saya menemukan bahwa orang yang bangun pagi lebih mampu membuat pilihan hidup yang lebih sehat," kata Jeff Sanders, penulis buku The 5 AM Miracle."Mereka lebih cenderung untuk berolahraga di pagi hari, makan sarapan yang sehat, dan memiliki waktu untuk membaca, yoga, doa, meditasi, atau kebiasaan sehat lainnya."Jika Anda sedang mencari alasan untuk mulai bangun pagi, berikut enam manfaat kesehatan yang dapat dijadikan pertimbangan.</p>\r\n\r\n<ol>\r\n<li>Anda Akan Terpancing untuk Berolahraga</li>\r\n<p align="justify">Menurut Women''s Health, sebuah studi yang disajikan dalam pertemuan tahunan Associated Professional Sleep Societies LLC menemukan bahwa bangun pagi cenderung untuk tidak melewatkan olahraga."Seperti yang terjadi pada diri saya, klien saya, dan orang yang bangun pagi lainnya. Jika tidak berolahraga di pagi hari, secara signifikan lebih kecil kemungkinannya untuk tidak berolahraga sama sekali," kata Sanders."Jadi, membiasakan diri untuk berolahraga rutin setiap pagi akan sangat bermanfaat untuk meningkatkan energi, kekuatan, dan banyak lagi."</p>\r\n\r\n<li>Sarapan Lebih Baik</li>\r\n<p align="justify">"Jika pernah bangun kesiangan, Anda pasti lebih memilih untuk mengambil donat sebagai bekal perjalanan bukannya mempersiapkan sarapan sehat," kata Sanders."Bangun pagi cenderung memberi cukup waktu untuk mempersiapkan sarapan yang menjadi sumber nutrisi dan energi."Satu penelitian dari Northwestern University menemukan bahwa orang yang tidur larut malam akan makan dua kali lebih banyak makanan cepat saji dan setengah jumlah buah-buahan dan sayuran dibanding orang yang tidur lebih awal.</p>\r\n\r\n<li>Suasana Hati Membaik</li>\r\n<p align="justify">Sebuah studi yang diterbitkan dalam jurnal Emotion menemukan bahwa orang yang bangun pagi lebih bahagia.Meskipun alasannya belum jelas, para peneliti menduga itu terjadi akibat mereka memusatkan kegiatan pada pagi hari.Sehingga kegiatan menjadi lebih cepat selesai dengan memberlakukan jadwal kegiatan dari jam 8 pagi sampai 5 sore.</p>\r\n\r\n<li>Menjadi Lebih Proaktif</li>\r\n<p align="justify">Ternyata, pepatah yang mengatakan "burung yang bangun lebih awal akan mendapatkan cacing" itu benar.Studi dari Harvard Business Review menemukan bahwa orang-orang yang bangun pagi lebih banyak memiliki tujuan dan akan merasa lebih bertanggung jawab membuat tujuan tersebut menjadi kenyataan.Mereka juga cenderung untuk mendapatkan nilai dan pekerjaan yang lebih baik.</p>\r\n\r\n<li>Lebih Waspada</li>\r\n<p align="justify">Jika Anda bangun di pagi hari tepat sebelum bekerja atau sekolah, Anda mungkin akan mengalami kondisi bernama sleep inertia yakni perasaan pening dan kurang bersemangat.Bangun tiba-tiba dapat membahayakan fungsi mental Anda seperti diantaranya menurunkan produktivitas dan memori.Sehingga, ada baiknya memberikan diri Anda beberapa saat untuk menyesuaikan diri sebelum terjaga dan berangkat menuju sekolah atau kantor dapat membantu meningkatkan kinerja Anda.</p>\r\n\r\n<li>Jadwal Tidur Lebih Konsisten</li>\r\n<p align="justify">"Kebiasaan bangun pagi yang sukses jelas memiliki waktu tidur lebih awal dan bangun pagi yang konsisten. Sehingga membuahkan kualitas istirahat yang butuhkan," kata Sanders."Fokus untuk bangun pagi dengan pola tidur berkualitas tinggi yang konsisten, secara dramatis dapat meningkatkan kesehatan Anda dengan sendirinya."Meskipun fungsi tubuh setiap individu memiliki jam yang berbeda, kebanyakan orang berfungsi optimal saat tidur mereka disinkronkan dengan ritme jam biologis alami.Jangan ragu untuk coba kebiasaan ini dan melihat bagaimana perasan Anda setelahnya.Mungkin Anda akan dihadapkan dengan kejutan yang menyenangkan.</p>\r\n\r\n<p align="justify">Referensi : <a href="http://www.tribunnews.com/kesehatan/2016/05/09/hasil-studi-bangun-pagi-meningkatkan-kualitas-kesehatan">http://www.tribunnews.com/kesehatan/2016/05/09/hasil-studi-bangun-pagi-meningkatkan-kualitas-kesehatan</a></p>\r\n', 1),
(7, 'Nyeri Lutut Jadi Masalah Kesehatan Dunia', '2016-04-30', '<p align="justify"><b>TRIBUNNEWS.COM, JAKARTA -</b> Nyeri lutut sampai saat ini masih menjadi masalah kesehatan utama di dunia.Diperkirakan kejadiannya mencapai 25 persen populasi, mulai dari anak-anak hingga lanjut usia.Nyeri lutut dapat datang secara tiba-tiba atau setelah trauma/cidera, termasuk sesaat setelah melakukan aktivitas fisik ringan atau berolahraga.dr. Ade Sri Wahyuni, SpRM, pakar Nyeri dari Klinik Nyeri dan Tulang Belakang, Jakarta, meski dapat sembuh dengan sendirinya, banyak kasus nyeri lutut yang menetap jika tidak diobati dengan segera sehingga dapat menghambat aktivitas penderitanya.Selain nyeri yang mengganggu, penderita umumnya juga mengalami sejumlah gejala lain seperti bengkak, kemerahan, dan kaku atau sulit untuk digerakan.\r\nLantas penyebab dan bagaimana gangguan nyeri lutut terjadi?Dalam dunia kedokteran, penyebab nyeri lutut dapat dibagi menjadi 4 kriteria, yaitu nyeri lutut yang disebabkan akibat cidera, masalah mekanis, radang sendi atau arthritis, dan penyebab lainnya.Selain cidera ACL (Anterior Cruciate Ligament) yang sudah banyak dikenal, nyeri lutut akibat cidera umumnya terjadi karena adanya masalah pada komponen-komponen penyangga lutut seperti ligamen, tendon, tulang rawan, dan kantong cairan sendi (bursae). Nyeri lutut dapat muncul karena adanya bursitis.“Bursitis merupakan peradangan atau pembengkakan bursae.</p>\r\n\r\n<p align="justify">Gejalanya rasa sakit, warna kulit yang memerah pada area yang mengalami peradangan," katanya di Jakarta. Rasa sakit ini biasanya memburuk saat tubuh bergerak atau mengalami tekanan dan area yang terkena terasa kaku serta bengkak.Kemudian ada gangguan mekanis yang berperan pada terjadinya nyeri lutut adalah Iliotibial Band Syndrome (ITBS) yang paling sering terjadi pada pelari.ITBS terjadi ketika jaringan ikat iliotibial atau IT band, ligamen yang terdapat di sepanjang bagian luar paha mulai dari pinggul sampai tulang kering; menjadi ketat dan meradang.IT band menempel pada lutut dan membantu stabilisasi serta gerak dari sendi. Ketika IT band tidak bekerja seperti seharusnya, pergerakan lutut akan menimbulkan rasa sakit.“Rasa sakit yang ditimbulkan bisa sangat parah,” jelasnya.Selain bursitis dan ITBS, penyebab nyeri lutut yang paling umum adalah artritis atau radang sendi.Jenis artritis yang dapat mengakibatkan terjadinya nyeri lutut di antaranya osteoartritis, arthritis reumatoid, gout, dan arthritis septik.Osteoartritis merupakan jenis artritis yang paling banyak ditemui dan disebut juga sebagai artritis degeneratif karena terjadi melalui proses penuaan.</p>\r\n\r\n<p align="justify">Osteoartritis ditandai dengan kerusakan tulang rawan (kartilago), pertumbuhan osteofit pada tepian sendi, meregangnya kapsul sendi, yang disertai peradangan.Jenis radang sendi lainnya adalah gout. Gout ditandai dengan adanya kristalisasi asam urat yang menumpuk pada sendi lutut atau sendi lainnya.Penumpukan kristal asam urat inilah yang selanjutnya menimbulkan nyeri berulang pada sendi.Selain beberapa kondisi diatas, sindrom nyeri patelofemoral juga menjadi salah satu penyebab terjadinya nyeri lutut.\r\nPenderita sindrome ini akan mengalami nyeri tepat dibagian depan lutut atau diantara patella dan tulang paha (femur) yang sering terjadi pada remaja, pekerja kasar dan juga atlit.Gejala nyeri akan muncul ketika penderita sindrome nyeri patelofemoral menaiki tangga, squat, joging atau melakukan lompatan.</p>\r\n\r\n<p align="justify">Referensi : <a href="http://www.tribunnews.com/kesehatan/2016/05/06/nyeri-lutut-jadi-masalah-kesehatan-dunia">http://www.tribunnews.com/kesehatan/2016/05/06/nyeri-lutut-jadi-masalah-kesehatan-dunia</a></p>\r\n', 1),
(8, 'Ada Anggapan Parkinson Adalah Gangguan di Tulang Hingga Penyakit Jiwa', '2016-04-28', '<p align="justify"><b>TRIBUNNEWS.COM, JAKARTA -</b> Pemahaman mengenai penyakit parkinson di masyarakat Indonesia masih sangat rendah. Bahkan, banyak anggapan berbagai gejala timbul justru dikira gangguan masalah tulang,   dikira saraf kejepit bahkan dibawa ke dokter jiwa karena dikira gangguan kejiwaan. "Parkinson, penyakit degeneratif yang menyerang sistem saraf (neurodegenerative) di bagian otak yang bernama basal ganglia yang berfungsi mengontrol gerakan tubuh," kata dr Frandy Susatia SpS dari Parkinson’s and Movement Disorder Center Siloam Hospitals Kebon Jeruk, Selasa (26/4/2016).Ia menyebutkan ada empat gejala utama yang menjadi pertanda bahwa seseorang menderita parkinson adalah gemetar saat istirahat, kekakuan gerak sendi saat bergerak, ketidakseimbangan postur tubuh, dan gerak menjadi lambat."Bahkan, kini sebelum keempat gejala tersebut muncul mengganggu aktivitas, timbul gangguan menghidu, yaitu kondisi tidak dapat mencium atau membaui sesuatu,” katanya.</p>\r\n\r\n<p align="justify">Parkinson memang tidak akan membuat seseorang meninggal, namun jika sudah stadium 5 pasien sudah bed-ridden, hanya bisa di tempat tidur yang berdampak pada berkurangnya kualitas hidup.Mengenai penanganan gangguan parkinson, Dr. dr. Made Agus M. Inggas, SpBS selaku dokter spesialis bedah saraf dari Parkinson’s and Movement Disorder Center bisa dilakukan dengan memberikan obat-obatan.”Tapi pemberian obat jangka panjang, maka obat dapat menjadi kurang efektif dan mempunyai efek samping," katanya.\r\nTeknologi terbaru, bisa dilakukan dengan melakukan  operasi Stimulasi Otak Dalam atau biasa disebut dengan Deep Brain Stimulation (DBS)."Operasi DBS akan membuat sel dopamin dapat dirangsang untuk memproduksi dopamin dan bekerja optimal kembali sehingga gejala penyakit parkinson dapat diatasi dan dosis obat berkurang,” katanya. DBS adalah operasi untuk mengatasi tremor, kaku, dan gerak yang lambat. Teknik operasi ini dilakukan melalui penanaman elektroda/ chip pada area tertentu di otak bagian dalam.Elektroda atau chip tersebut dihubungkan dengan kabel ke baterai yang diletakkan di dalam dada sebagai sumber arus listrik.Rata-rata pasien merasakan peningkatan perbaikan motorik sekitar 75-87 persen setelah dioperasi pada keadaan tanpa obat."DBS telah disetujui oleh Food and Drug Administration (FDA) Amerika untuk pengobatan Essential Tremor (ET), Penyakit Parkinson (PD), Dystonia, dan Obsessive Compulsive Disorder (Sindrom Tourette)," katanya. Operasi Deep Brain Stimulation ini tersedia di Parkinson’s and Movement Disorder Center Siloam Hospitals.Juga menghadirkan layanan tata laksana komprehensif penyakit parkinson dan gangguan gerak lainnya  yakni Klinik Botulinum Toxin (Botox), Operasi Thalamotomy, Operasi Pallidotomy, dan program rehabilitasi bagi pasien penyakit parkinson dan gangguan gerak lainnya.</p>\r\n\r\n<p align="justify">Referensi : <a href="http://www.tribunnews.com/kesehatan/2016/04/26/ada-anggapan-parkinson-adalah-gangguan-di-tulang-hingga-penyakit-jiwa">http://www.tribunnews.com/kesehatan/2016/04/26/ada-anggapan-parkinson-adalah-gangguan-di-tulang-hingga-penyakit-jiwa</a></p>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE `dokter` (
  `id_dokter` int(15) NOT NULL,
  `nama_dokter` varchar(35) NOT NULL,
  `jk_dokter` varchar(15) NOT NULL,
  `spesialis` varchar(20) NOT NULL,
  `alamat_dokter` varchar(50) NOT NULL,
  `jadwal_kerja` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id_dokter`, `nama_dokter`, `jk_dokter`, `spesialis`, `alamat_dokter`, `jadwal_kerja`) VALUES
(1, 'Dr. Agnes Harsanti Sp.M', 'Perempuan', 'Mata', 'Jl. Seperempat no.49', 'Selasa dan Kamis'),
(2, 'Dr. Alan Julian Sp.K', 'Laki-Laki', 'Kulit', 'Jl. Keliling Lingkaran no.1778', 'Senin dan Kamis'),
(3, 'Dr. Amelia Widya A.,Sp.PD', 'Perempuan', 'Penyakit Darah', 'Jl. Jajargenjang no. 293', 'Senin dan Rabu'),
(4, 'Dr. Angel Liana Sp.K', 'Perempuan', 'Kandungan', 'Jl. Pitagoras DN2/no.12', 'Senin dan Selasa'),
(5, 'Dr. Donna Brilian Sp.U', 'Perempuan', 'Umum', 'Jl.Simpangan Baku no.226', 'Rabu dan Kamis'),
(6, 'Dr. Eko Jatmiko Sp.G', 'Laki-Laki', 'Gigi', 'Jl. Aritmatika no.165', 'Senin dan Rabu'),
(7, 'Dr. Hafiz Sudrajat Sp.A', 'Laki-Laki', 'Anak', 'Jl. Simpangan Rata no.129', 'Jum''at dan Sabtu'),
(8, 'Dr. Priska Amalia Sp.U', 'Perempuan', 'Umum', 'Jl. Trapesium no.403', 'Jumat dan Sabtu'),
(9, 'Dr. Resa Adijaya Sp.U', 'Laki-Laki', 'Umum', 'Jl. Setengah Lingkaran no.24', 'Senin dan Selasa'),
(10, 'Dr. Rizal Hendarta Sp.K', 'Laki-Laki', 'Kandungan', 'Jl. Kubus no.2', 'Kamis dan Jumat');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `id_jadwal` int(11) NOT NULL,
  `nama_jadwal` varchar(30) NOT NULL,
  `hari_jadwal` varchar(30) NOT NULL,
  `jam_jadwal` varchar(20) NOT NULL,
  `id_user` int(11) NOT NULL,
  `deskripsi_jadwal` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`id_jadwal`, `nama_jadwal`, `hari_jadwal`, `jam_jadwal`, `id_user`, `deskripsi_jadwal`) VALUES
(1, 'JADWAL PELAYANAN KHUSUS GIGI', 'Senin dan Rabu', '08.30 - 11.30 WIB', 1, '<p align="justify">Pelayanan ini dikhususkan bagi warga masyarakat yang ingin memeriksakan kesehatan gigi, karena pada hari senin dan rabu terdapat jadwal dokter yang khusus spesialis gigi. Oleh karena itu bagi masyarakat yang sekiranya ingin memeriksakan gigi, bisa datang pada hari dan jam yang telah tertera di atas, karena selain terdapat dokter umum terdapat juga dokter yang khusus menangani masalah gigi, atau bisa dibilang ahlinya. Walaupun setiap hari puskesmas juga menerima pasien periksa gigi dengan dokter umum, akan tetapi pada hari-hari tertentu kami siapkan dokter dengan spesialis khusus untuk pemeriksaan yang lebih baik.</p>'),
(2, 'JADWAL PELAYANAN KHUSUS MATA', 'Selasa dan Kamis', '08.30 - 11.30 WIB', 1, '<p align="justify">Pelayanan ini dikhususkan bagi warga masyarakat yang ingin memeriksakan kesehatan mata, karena pada hari selasa dan kamis terdapat jadwal dokter yang khusus spesialis mata. Oleh karena itu bagi masyarakat yang sekiranya ingin memeriksakan mata, bisa datang pada hari dan jam yang telah tertera di atas, karena selain terdapat dokter umum terdapat juga dokter yang khusus menangani masalah mata, atau bisa dibilang ahlinya. Walaupun setiap hari puskesmas juga menerima pasien periksa mata dengan dokter umum, akan tetapi pada hari-hari tertentu kami siapkan dokter dengan spesialis khusus untuk pemeriksaan yang lebih baik.</p>'),
(3, 'JADWAL PELAYANAN KHUSUS KULIT', 'Senin dan Kamis', '08.30 - 11.30 WIB', 1, '<p align="justify">Pelayanan ini dikhususkan bagi warga masyarakat yang ingin melakukan pemeriksaan gangguan pada kulit, yaitu meliputi alergi pada kulit, penyakit mata ikan pada telapan kaki, dll. Walaupun setiap hari puskesmas juga menerima pasien Bedah dengan dokter umum, akan tetapi pada hari-hari tertentu kami siapkan dokter dengan spesialis khusus untuk pemeriksaan yang lebih baik.</p>'),
(4, 'PELAYANAN  PEMERIKSAAN DARAH', 'Senin dan Rabu', '08.30 - 11.30 WIB', 1, '<p align="justify">Pelayanan ini dikhususkan bagi warga masyarakat yang menderita penyakit dalam seperti hipertensi, migrain, periksa kadar gula, dll bisa datang pada hari dan jam yang telah tertera di atas, karena pada jadwal di atas terdapat  jadwal praktik dari dokter dengan spesialis penyakit dalam (darah). Walaupun setiap hari puskesmas juga menerima pasien penyakit dalam dengan dokter umum, akan tetapi pada hari-hari tertentu kami siapkan dokter dengan spesialis khusus untuk pemeriksaan yang lebih baik.</p>'),
(5, 'PELAYANAN KHUSUS KANDUNGAN', 'Senin,Selasa,Kamis dan Jum''at', '08.30 - 11.30 WIB', 1, '<p align="justify">Pelayanan ini dikhususkan bagi warga masyarakat khususnya bagi ibu-ibu yang sedang mengandung, karena pada hari dan jam yang telah tertera di atas, terdapat jadwal praktik dokter khusus spesialis kandungan. Walaupun setiap hari puskesmas juga menerima pasien Ibu Hamil dengan dokter umum, akan tetapi pada hari-hari tertentu kami siapkan dokter dengan spesialis khusus untuk pemeriksaan yang lebih baik.</p>'),
(6, 'JADWAL PELAYANAN UMUM', 'Senin - Sabtu', '08.30 - 11.30 WIB', 1, '<p align="justify">Pelayanan umum adalah suatu layanan yang disediakan oleh PUSKESMAS KITA untuk memberikan pelayanan bagi masayarakat secara umum, dan khususnya untuk wilayah seputar PUSKESMAS KITA dan khusus bagi warga masyarakat yang kurang mampu. Di dalam pelayanan ini secara umum ditangani oleh Dokter Umum, akan tetapi selain dokter umum juga terdapat dokter dengan spesialis tertentu yang telah terjadwalkan. Pelayanan Umum ini dibuka setiap hari yaitu pada hari senin sampai hari sabtu sesuai jam yang tertera di atas.</p>'),
(7, 'JADWAL PELAYANAN KHUSUS ANAK', 'Jum''at dan Sabtu', '08.30 - 11.30 WIB', 1, '<p align="justify">Pelayanan ini dikhususkan bagi warga masyarakat yang ingin memeriksakan anaknya, karena selain terdapat dokter umum, kami siapkan juga seorang dokter khusus dengan spesialis anak pada hari-hari tertentu yang telah tertera di atas. Walaupun setiap hari puskesmas juga menerima pasien Anak dengan dokter umum, akan tetapi pada hari-hari tertentu kami siapkan dokter dengan spesialis khusus untuk pemeriksaan yang lebih baik.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `kategori_tarif`
--

CREATE TABLE `kategori_tarif` (
  `id_kategori_tarif` int(11) NOT NULL,
  `nama_kategori_tarif` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori_tarif`
--

INSERT INTO `kategori_tarif` (`id_kategori_tarif`, `nama_kategori_tarif`) VALUES
(1, 'Pelayanan Umum'),
(2, 'Pelayanan Gigi'),
(3, 'Pelayanan Mata'),
(4, 'Pelayanan Kandungan'),
(5, 'Pelayanan Penyakit Kulit'),
(6, 'Pemeriksaan Darah'),
(7, 'Pelayanan Anak');

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `id_pegawai` int(10) NOT NULL,
  `nama_pegawai` varchar(30) NOT NULL,
  `jk_pegawai` varchar(15) NOT NULL,
  `jabatan` varchar(20) NOT NULL,
  `alamat_pegawai` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nama_pegawai`, `jk_pegawai`, `jabatan`, `alamat_pegawai`) VALUES
(1, 'Raisa Citra Lestari, S.AP', 'Perempuan', 'Administrasi', 'Jalan Komputer Grafis No.1'),
(2, 'Riko Ahmad, S.AP', 'Laki-Laki', 'Administrasi', 'Jalan Android No.8'),
(3, 'Hartono Purnomo', 'Laki-Laki', 'Cleaning Service', 'Jalan Qualcom No.47'),
(4, 'Riyan Wibowo', 'Laki-Laki', 'Cleaning Service', 'Jalan Smartphone No.91'),
(5, 'Hadi Maryono', 'Laki-Laki', 'Cleaning Service', 'Jalan Gingerbeard No.12 '),
(6, 'Agus Prasetyo, S.Farm', 'Laki-Laki', 'Kepala Apoteker', 'Jalan Pemrograman No.7'),
(7, 'Anang Farodli, S.Farm', 'Laki-Laki', 'Apoteker', 'Jalan Algoritma No.9'),
(8, 'Lia Santika, S.Farm', 'Perempuan', 'Apoteker', 'Jalan Komunikasi Data No.3'),
(9, 'Devi Setiawati, S.Kep', 'Perempuan', 'Kepala Perawat', 'Jalan Pascal No.11'),
(10, 'Alfihatus Sholeha, S.kep', 'Perempuan', 'Perawat', 'Jalan iOS No.69'),
(11, 'Deni Prakoso, S.kep', 'Laki-Laki', 'Perawat', 'Jalan User Interface No51'),
(12, 'Dian Marshanda, S.kep', 'Perempuan', 'Perawat', 'Jalan Marsmallow No.31'),
(13, 'Nia Santika, S.kep', 'Perempuan', 'Perawat', 'Jalan Ethernet No.07'),
(14, 'Asinta Dwi Rahmawati, S.kep', 'Perempuan', 'Perawat', 'Jalan QuadCore No.79'),
(15, 'Citra Indriyana, S.B', 'Perempuan', 'Kepala Bidan', 'Jalan Coding No.06'),
(16, 'Viky Citra Lestari, S.B', 'Perempuan', 'Bidan', 'Jalan Linux No.10');

-- --------------------------------------------------------

--
-- Table structure for table `tarif`
--

CREATE TABLE `tarif` (
  `id_tarif` int(11) NOT NULL,
  `nama_tarif` varchar(30) NOT NULL,
  `harga_tarif` varchar(15) NOT NULL,
  `id_kategori_tarif` int(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tarif`
--

INSERT INTO `tarif` (`id_tarif`, `nama_tarif`, `harga_tarif`, `id_kategori_tarif`, `id_user`) VALUES
(1, 'Scalling Atas atau Bawah', 'Rp.6000,00', 2, 1),
(2, 'Pencabutan Gigi Anak', 'Rp.4000,00', 2, 1),
(3, 'Pencabutan Gigi Dewasa', 'Rp.14.000,00', 2, 1),
(4, 'Penambahan Gigi Sementara', 'Rp.3000,00', 2, 1),
(5, 'Penambalan Gigi Tetap Amalgam', 'Rp.7.500,00', 2, 1),
(6, 'Penambahan Gigi Komposit', 'Rp.12.000,00', 2, 1),
(7, 'Pasang Gigi Tiruan Sebagian', 'Rp.125.000,00', 2, 1),
(8, 'Pasang Gigi Tiruan Lengkap', 'Rp.250.000,00', 2, 1),
(9, 'Pemeriksaan Hemoglobin', 'Rp.8.000,00', 6, 1),
(10, 'Periksa Hit. Leukosit', 'Rp.5.000,00', 6, 1),
(11, ' Periksa PCV/Hematrokit/LED', 'Rp.3.000,00', 6, 1),
(12, 'Cek Golongan Darah', 'Rp.8.000,00', 6, 1),
(13, 'Periksa Hit.Trombosit', 'Rp.7.000,00', 6, 1),
(14, 'Periksa Darah Lengkap', 'Rp.20.000,00', 6, 1),
(15, 'Periksa Glukosa', 'Rp.10.000,00', 6, 1),
(16, 'Periksa Asam Urat', 'Rp.10.000,00', 6, 1),
(17, 'Periksa Kolesterol', 'Rp.15.000,00', 6, 1),
(18, 'Periksa Trigleserida', 'Rp.14.000,00', 6, 1),
(19, 'Periksa Tekanan Darah', 'Rp.2.000,00', 1, 1),
(20, 'Periksa Flu dan Demam', 'Rp.5.000,00', 1, 1),
(21, 'Periksa Laboratorium', 'Rp.30.000,00', 1, 1),
(22, 'Konsultasi Kehamilan', 'Rp.5.000,00', 4, 1),
(23, 'Periksa Kesehatan Kandungan', 'Rp.15.000,00', 4, 1),
(24, 'Konsultasi KB', 'Rp.3.000,00', 4, 1),
(25, 'Pemasangan Alat KB', 'Rp.12.000,00', 4, 1),
(26, 'Cek Keamanan Alat KB', 'Rp.6.000,00', 4, 1),
(27, 'Pelepasan Alat KB', 'Rp.12.000,00', 4, 1),
(28, 'Operasi Luka Ringan', 'Rp.10.000,00', 1, 1),
(29, 'Konsultasi Kulit Wajah', 'Rp.5.000,00', 5, 1),
(30, 'Periksa Alergi', 'Rp.7.000,00', 5, 1),
(31, 'Periksa Mata Ikan', 'Rp.10.000,00', 5, 1),
(32, 'Periksa Luka Bakar di Kulit', 'Rp.10.000,00', 5, 1),
(33, 'Imunisasi Balita', 'Rp.2.000,00', 7, 1),
(34, 'Pemberian Vaksin', 'Rp.2.000,00', 7, 1),
(35, 'Periksan Demam  Tinggi dan Ste', 'Rp.7.000,00', 7, 1),
(36, 'Pemantauan Pertumbuhan Balita', 'Rp.4.000,00', 7, 1),
(37, 'Pemeriksaan Gizi Anak', 'Rp.8.000,00', 7, 1),
(38, 'Periksa Gangguan Penglihatan', 'Rp.8.000,00', 3, 1),
(39, 'Tes Buta Warna', 'Rp.5.000,00', 3, 1),
(40, 'Periksa Katarak', 'Rp.15.000,00', 3, 1),
(41, 'Periksa Radang pada Mata', 'Rp.10.000,00', 3, 1),
(42, 'Pemantauan Pertumbuhan Anak', 'Rp.5.000,00', 7, 1),
(43, 'Pemeriksaan Kesehatan Balita', 'Rp.8.000,00', 7, 1),
(44, 'Imunisasi Pencegahan Penyakit', 'Rp.5.000,00', 7, 1),
(45, 'Periksa Gangguan Pencernaan An', 'Rp.7.000,00', 7, 1),
(46, 'Imunisasi Pencegahan Penyakit', 'Rp.8.000,00', 7, 1),
(47, 'Pemantauan Pertumbuhan Balita', 'Rp.6.000,00', 7, 1),
(48, 'Cek Gangguan Pencernaan Anak', 'Rp.10.000,00', 7, 1),
(49, 'Periksa Gizi Anak', 'Rp.9.000,00', 7, 1),
(50, 'Tes Keterangan Sehat Jasmani', 'Rp.10.000,00', 1, 1),
(51, 'Pelayanan USG', 'Rp.50.000,00', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(30) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `username`, `password`) VALUES
(1, 'administrator', 'admin', 'uchiha2396');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`id_agenda`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id_berita`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`id_dokter`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `kategori_tarif`
--
ALTER TABLE `kategori_tarif`
  ADD PRIMARY KEY (`id_kategori_tarif`),
  ADD KEY `id_kategori_tarif` (`id_kategori_tarif`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indexes for table `tarif`
--
ALTER TABLE `tarif`
  ADD PRIMARY KEY (`id_tarif`),
  ADD KEY `id_tarif` (`id_tarif`),
  ADD KEY `id_kategori_tarif` (`id_kategori_tarif`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_user_2` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agenda`
--
ALTER TABLE `agenda`
  MODIFY `id_agenda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id_berita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
  MODIFY `id_dokter` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `id_jadwal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `kategori_tarif`
--
ALTER TABLE `kategori_tarif`
  MODIFY `id_kategori_tarif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id_pegawai` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `tarif`
--
ALTER TABLE `tarif`
  MODIFY `id_tarif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `agenda`
--
ALTER TABLE `agenda`
  ADD CONSTRAINT `agenda_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `berita`
--
ALTER TABLE `berita`
  ADD CONSTRAINT `berita_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD CONSTRAINT `jadwal_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tarif`
--
ALTER TABLE `tarif`
  ADD CONSTRAINT `tarif_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tarif_ibfk_2` FOREIGN KEY (`id_kategori_tarif`) REFERENCES `kategori_tarif` (`id_kategori_tarif`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
