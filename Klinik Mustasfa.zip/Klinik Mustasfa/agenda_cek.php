<html>
<head>
<title>Halaman Agenda</title>
<link rel="stylesheet" type="text/css" href="css/style2.css">
	<title>Admin</title>
</head>
<body background="logo.png">

	<table class="admin" border="2px">
		<tr>
			<td colspan="2" class="namaadmin">
				<h1 class="namaadmin">WELCOME ADMIN</h1>
			</td>
		</tr>
		<tr>
			<td bgcolor="" class="menuadmin">
				<a href="welcome.php">Home</a></input>
			</td>
			<td class="tengah2" rowspan="3" align="justify" >
			<h2 align="center">Detail Agenda</h2>
<?php
include("koneksi.php");
$sql = "SELECT * FROM agenda WHERE id_agenda = ".$_GET['id'];
$hasil = mysql_query($sql);
$data = mysql_fetch_assoc($hasil);
echo "ID AGENDA : ".$data['id_agenda'];
echo "<br /><br />";
echo "NAMA AGENDA : ".$data['nama_agenda'];
echo "<br /><br />";
echo "TANGGAL AGENDA : ".$data['tanggal_hari'];
echo "<br /><br />";
echo "JAM AGENDA : ".$data['jam_agenda'];
echo "<br /><br />";
echo "TEMPAT AGENDA : ".$data['tempat_agenda'];
echo "<br /><br />";
echo "DESKRIPSI AGENDA : ".$data['deskripsi_agenda'];
echo "ID USER : ".$data['id_user'];

?>
</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="berita_tampil.php">Berita</a>
			</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="agenda_tampil.php">Agenda</a>
			</td>
		</tr>
		</table>
		</body>
</html>