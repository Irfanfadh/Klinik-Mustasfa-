 <!DOCTYPE html>
<html>
<head>
  <title>Puskesmas Kita</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
          <!--bagian header logo dan search-->
<div class="row sisi">
  <div class="col-md-4 logo">
   
      <span class="logos">
      <img src="img/logo.png"/>
       </span>
       <!--login-->
      <span class="login">
         <form action="login.php" method="post">
         <table cellpadding="5px" bgcolor="#ccc">
         <tr>
         <td class="nm">
Username : </td>
<td><input class="nma" type="text" name="txtUsername"/></td>
</tr>
<tr>
<td class="nm">Password : </td>
<td><input class="nma" type="password" name="txtPassword"/>
</td></tr>
<tr><td></td>
<td><input class="kirim" type="submit" value="Login" />
</td></tr>
</table>
</form>
      </span>
      <!--end login-->
      
  </div>
</div>
  <!--slider-->
<div col-md-12 class="slide">
  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
    <li data-target="#carousel-example-generic" data-slide-to="4"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="img/tunggu.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>ruang tunggu</p>
        <p>Ruang tunngu yang nyaman dan dilengkapi fasiitas TV LCD yang menyiarkan berita seputar kesehatan dan tips tips kesehatan sehingga pasien mendapatkan informasi seputar kesehatan</p>
      </div>
    </div>
    <div class="item">
      <img src="img/parkiran.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>lapangan parkir yang luas</p>
        <p>lapangan parkir yang disediakan puskesmas tidak hanya cukup untuk motor tetapi juga mobil serta dilengkapi fasilitas gazebo untuk tempat menunggu pengantar pasien</p>
      </div>
    </div>
     <div class="item">
      <img src="img/pelayanan.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>pelayanan ramah</p>
        <p>pelayanan kami yang ramah membuat pasien merasa nyaman dan termotivasi untuk kembali sehat dan dapat menenangkan pasien selama masa perawatan</p>
      </div>
    </div>
    <div class="item">
      <img src="img/usg.png" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>fasilitas kehamilan</p>
        <p>pengecekkan kandungan sudah menggunakan USG 4 Dimensi yang sudah memungkinkan ibu hamil melihat kondisi bayinya secara jelas</p>
      </div>
    </div>
    <div class="item">
      <img src="img/masjid.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>tempat ibadah</p>
        <p>Puskesmas Kita juga dilengkapi dengan mushola yang nyaman dan bersih, alat sholat yang rutin dibersihkan sehingga membuat pasien yang ingin beribadah jadi nyaman dan tidak khawatir dengan kebersihannya</p>
      </div>
    </div>
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

          <!--menu-->
          <div class="menu navbar navbar-inverse">
            <div class="container">
              <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
          </div>
          <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li><a href="index.php">HOME</a></li>
            <li class="dropdown">
          <a href="profile.php" target="_blank" class="dropdown-toggle" data-toggle="dropdown">PROFILE</a>
          <ul class="dropdown-menu turun">
            <li><a class="tulis" href="visimisi.php">Visi-Misi</a></li>
            <li><a href="sambutan.php">Sambutan</a></li>
          </ul>
        </li>
            <li><a target="_blank" href="dokter.php">DATA DOKTER</a></li>
            <li><a target="_blank" href="pegawai.php">DATA PEGAWAI</a></li>
             <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">INFORMASI</a>
          <ul class="dropdown-menu turun">
            <li><a href="layanan.php" target="_blank">Pelayanan</a></li>
            <li><a href="agenda.php" target="_blank">Agenda</a></li>
          </ul>
        </li>
            </ul>
          </div>
          </div>
</div>
<!--end menu-->

<!--tanda-->
  <div>
    <table class="tanda">
      <tr>
        <td class="tanda2">Berita</td>
      </tr>
    </table>
  </div>
  <!--konten-->
 <table class="tabel">
 	<tr>
 		<td class="tabelkiri">
 			<img class="gambar img-circle" src="img/berita1.jpg">
 		</td>
 		<td class="tabelkanan">
 			<h3 class="brta1"><a href="berita.php">Hindari Jenis-jenis Makanan Ini Jika Kadar Trigliserida Anda Sedang Tinggi</a></h3>
 			<p class="brta1"><b>TRIBUNNEWS.COM, JAKARTA---</b> Trigliserida merupakan jenis lemak darah yang sebenarnya digunakan untuk memberikan energi. Namun, jika kadarnya terlalu tinggi bisa meningkatkan risiko penyakit jantung dan stroke.
Kadar trigliserida yang dinyatakan sehat adalah di bawah 150 mg/dL, sementara 150-199 mg/dL harap berhati-hati, dan 200-499 mg/dL termasuk tidak sehat. Di atas 499 mg/dL sangat tidak sehat.
Kadar trigliserida tinggi jangan diremehkan. Pada banyak kasus, dokter akan meresepkan obat-obatan untuk...<a href="berita.php">Baca Selengkapnya</a></p>
 		</td>
 	</tr>
 	<tr>
 		<td class="tabelkiri">
 			<img class="gambar img-circle" src="img/berita2.jpg">
 		</td>
 		<td class="tabelkanan">
 			<h3 class="brta1"><a href="berita2.php">Beberapa Hal Ini Bikin Daya Tahan Tubuh Lemah</a></h3>
 			<p class="brta1"><b>TRIBUNJOGJA.COM - </b>Apakah yang mampu menghentikan infeksi patogen dari luar merusak sel-sel tubuh? Hanya sistem kekebalan tubuh yang bisa melakukannya. Tanpa sistem imun yang baik, tubuh kita tak akan bisa bertahan sampai sekarang.
Meski begitu, seiring dengan pertambahan usia dan gaya hidup, sistem kekebalan tubuh bisa menjadi lemah dan lelah. Ketika "tentara" di tubuh kita lemah, maka tugasnya untuk melindungi kita tak bisa dilakukan.</p>
<p class="brta1">Dengan mengenali faktor-faktor apa yang membuat daya tahan tubuh rendah, kita bisa melakukan banyak hal untuk membuatnya tetap kuat.
Berikut ini adalah beberapa faktor yang bisa membuat sistem imun lemah...<a href="berita2.php">Baca Selengkapnya</a></p>
 		</td>
 	</tr>
 	<tr>
 		<td class="tabelkiri">
 			<img class="gambar img-circle" src="img/berita3.jpg">
 		</td>
 		<td class="tabelkanan">
 			<h3 class="brta1"><a href="berita3.php">Jangan Abaikan 6 Jenis Sakit Kepala Ini, Segeralah ke Dokter Jika Mengalaminya</a></h3>
 			<p class="brta1"><b>TRIBUNJOGJA.COM - </b>Jika sakit kepala sudah mengganggu kehidupan Anda dan menyebabkan rasa sakit kronis, jangan enggan untuk segera mendapatkan bantuan medis.
Berikut beberapa gejala sakit kepala yang sebaiknya ditangani oleh dokter :...<a href="berita3.php">Baca Selengkapnya</a></p>
 		</td>
 	</tr>
 	<tr>
 		<td class="tabelkiri">
 			<img class="gambar img-circle" src="img/berita4.jpg">
 		</td>
 		<td class="tabelkanan">
 			<h3 class="brta1"><a href="berita4.php">Menristek: Penanganan DBD Bukan Membunuh Nyamuk Aedes Aegypti</a></h3>
 			<p class="brta1"><b>Laporan Reporter Tribun Jogja, Kurniatul Hidayah
TRIBUNJOGJA.COM, SLEMAN -</b>Menteri Riset, Teknologi dan Pendidikan Tinggi, Muhammad Nasir menyatakan bahwa sistem pengendalian Demam Berdarah Dengue (DBD) yang dilakukan oleh Eliminate Dengue Project (EDP-Yogya), menjadi solusi yang luar biasa untuk kasus DBD di Indonesia...<a href="berita4.php">Baca Selengkapnya</a></p>
 		</td>
 	</tr>
 	<tr>
 		<td class="tabelkiri">
 			<img class="gambar img-circle" src="img/berita5.jpg">
 		</td>
 		<td class="tabelkanan">
 			<h3 class="brta1"><a href="berita5.php">Penderita Diabetes Tak Selalu Harus Berpantang Makanan</a></h3>
 			<p class="brta1"><b>TRIBUNNEWS.COM -</b>Vonis diabetes kerap memupus asa untuk menyantap makanan enak. Berbagai jenis makanan terpaksa dianggap musuh. Misalnya, menjauhi gula karena dianggap sebagai pemicu diabetes. Tapi, tak semua itu benar. Berikut fakta dan mitos mengenai pola makan bagi para pengidap diabetes :...<a href="berita5.php">Baca Selengkapnya</a></p>
 		</td>
 	</tr>
 	<tr>
 		<td class="tabelkiri">
 			<img class="gambar img-circle" src="img/berita6.jpg">
 		</td>
 		<td class="tabelkanan">
 			<h3 class="brta1"><a href="berita6.php">Hasil Studi: Bangun Pagi Meningkatkan Kualitas Kesehatan</a></h3>
 			<p class="brta1"><b>TRIBUNNEWS.COM -</b> Beberapa orang benci bangun pagi dan memilih untuk bangun lebih siang.Namun, ada baiknya untuk menghilangkan prilaku itu dan mengubahnya sekarang juga.Pasalnya, bangun pagi terbukti mampu meningkatkan kesehatan."Bangun pagi membuat manusia lebih konsisten dengan siklus jam biologisnya," kata Alcibiades J Rodriguez MD, asisten profesor, Departemen Neurologi, NYU Langone Comprehensive Epilepsy Center-Sleep Center."Sinar matahari adalah stimulan paling kuat dalam memberi energi dan meningkatkan mood Anda, sehingga Anda bisa memulai aktivitas dengan tubuh Anda lebih segar."Bangun lebih awal mungkin tidak langsung menyebabkan adanya perbaikan kesehatan, tapi dapat membantu orang beradaptasi pada kebiasaan sehat yang dapat membantu meningkatkan kehidupan mereka secara keseluruhan."Saya menemukan bahwa orang yang bangun pagi...<a href="berita6.php">Baca Selengkapnya</a></p>
 		</td>
 	</tr>
 	<tr>
 		<td class="tabelkiri">
 			<img class="gambar img-circle" src="img/berita7.jpg">
 		</td>
 		<td class="tabelkanan">
 			<h3 class="brta1"><a href="berita7.php">Nyeri Lutut Jadi Masalah Kesehatan Dunia</a></h3>
 			<p class="brta1"><b>TRIBUNNEWS.COM, JAKARTA -</b> Nyeri lutut sampai saat ini masih menjadi masalah kesehatan utama di dunia.Diperkirakan kejadiannya mencapai 25 persen populasi, mulai dari anak-anak hingga lanjut usia.Nyeri lutut dapat datang secara tiba-tiba atau setelah trauma/cidera, termasuk sesaat setelah melakukan aktivitas fisik ringan atau berolahraga.dr. Ade Sri Wahyuni, SpRM, pakar Nyeri dari Klinik Nyeri dan Tulang Belakang, Jakarta, meski dapat sembuh dengan sendirinya, banyak kasus nyeri lutut yang...<a href="berita7.php">Baca Selengkapnya</a></p>
 		</td>
 	</tr>
 	<tr>
 		<td class="tabelkiri">
 			<img class="gambar img-circle" src="img/berita8.jpg">
 		</td>
 		<td class="tabelkanan">
 			<h3 class="brta1"><a href="berita8.php">Ada Anggapan Parkinson Adalah Gangguan di Tulang Hingga Penyakit Jiwa</a></h3>
 			<p class="brta1"><b>TRIBUNNEWS.COM, JAKARTA -</b> Pemahaman mengenai penyakit parkinson di masyarakat Indonesia masih sangat rendah. Bahkan, banyak anggapan berbagai gejala timbul justru dikira gangguan masalah tulang,   dikira saraf kejepit bahkan dibawa ke dokter jiwa karena dikira gangguan kejiwaan. "Parkinson, penyakit degeneratif yang menyerang sistem saraf (neurodegenerative) di bagian otak yang bernama basal ganglia yang berfungsi mengontrol gerakan tubuh," kata dr Frandy Susatia SpS dari Parkinson’s and Movement Disorder Center Siloam Hospitals Kebon Jeruk, Selasa (26/4/2016).Ia menyebutkan ada empat gejala utama yang menjadi pertanda bahwa seseorang menderita parkinson adalah...<a href="berita8.php">Baca Selengkapnya</a></p>
 		</td>
 	</tr>
 </table>

    <!--footer-->
    <div class="footer">
        <p>Ring Road Utara KM 10</br>
        Condong Catur, Sleman</br>
        D.I. Yogyakarta</br>
        (0274)446756/662819</p>
     </div>
 
  <!--Pemanggilan Java Script-->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.js"></script>
</body>
</html>