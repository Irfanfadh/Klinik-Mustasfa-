<html>
<head>
<title>Halaman Agenda</title>
<link rel="stylesheet" type="text/css" href="css/style2.css">
	<title>Admin Agenda</title>
</head>
<body>

	<table class="admin" border="2px">
		<tr>
			<td class="namaadmin" colspan="2">
				<h1 class="namaadmin">WELCOME ADMIN</h1>
			</td>
		</tr>
		<tr>
			<td class="menuadmin">
				<a href="welcome.php">Home</a></input>
			</td>
			<td class="tengah2" rowspan="3">
				<h2>Daftar Agenda</h2>
<p><a href="tambah_agenda.php"><input type="button"/ value="Tambah Data"></a></p>
<table width="auto" border="1">
<tr style="background:#ccc">
<th width="auto">ID AGENDA</th>
<th width="auto">NAMA AGENDA</th>
<th width="auto">TANGGAL AGENDA</th>
<th width="auto">JAM AGENDA</th>
<th width="auto">TEMPAT AGENDA</th>
<th width="auto">DESKRIPSI AGENDA</th>
<th width="auto">ID USER</th>
<th colspan="3" width="auto">AKSI</th>
</tr>
<?php
include("koneksi.php");
$sql = "SELECT id_agenda,nama_agenda,tanggal_hari,jam_agenda,tempat_agenda,deskripsi_agenda,id_user FROM agenda";
$hasil = mysql_query($sql) or exit("Error query: <b>".$sql."</b>.");
while($data = mysql_fetch_assoc($hasil)){
?>
<tr>
<td align="center"><?php echo $data['id_agenda']; ?></td>
<td><?php echo $data['nama_agenda']; ?></td>
<td><?php echo $data['tanggal_hari']; ?></td>
<td><?php echo $data['jam_agenda']; ?></td>
<td><?php echo $data['tempat_agenda']; ?></td>
<td><?php echo $data['deskripsi_agenda']; ?></td>
<td><?php echo $data['id_user']; ?></td>
<td>
<a href="agenda_ubah.php?id=<?php echo $data['id_agenda']; ?>">
Ubah
</a>
</td>
<td>
<a href="agenda_cek.php?id=<?php echo $data['id_agenda']; ?>">
Lihat
</a>
</td>
<td>
<a href="hapus_agenda.php?id=<?php echo $data['id_agenda']; ?>">
Hapus
</a>
</td>
</tr>
<?php
}
?>
</table>
			</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="berita_tampil.php">Berita</a>
			</td>
		</tr>
		<tr class="menuadmin">
			<td>
				<a href="agenda_tampil.php">Agenda</a>
			</td>
		</tr>
		</table>

</body>
</html>