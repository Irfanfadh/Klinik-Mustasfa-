 <!DOCTYPE html>
<html>
<head>
  <title>Puskesmas Kita</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
          <!--bagian header logo dan search-->
<div class="row sisi">
  <div class="col-md-4 logo">
   
      <span class="logos">
      <img src="img/logo.png"/>
       </span>
       <!--login-->
      <span class="login">
         <form action="login.php" method="post">
         <table cellpadding="5px" bgcolor="#ccc">
         <tr>
         <td class="nm">
Username : </td>
<td><input class="nma" type="text" name="txtUsername"/></td>
</tr>
<tr>
<td class="nm">Password : </td>
<td><input class="nma" type="password" name="txtPassword"/>
</td></tr>
<tr><td></td>
<td><input class="kirim" type="submit" value="Login" />
</td></tr>
</table>
</form>
      </span>
      <!--end login-->
      
  </div>
</div>

  <!--slider-->
<div col-md-12 class="slide">
  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
    <li data-target="#carousel-example-generic" data-slide-to="4"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="img/tunggu.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>ruang tunggu</p>
        <p>Ruang tunngu yang nyaman dan dilengkapi fasiitas TV LCD yang menyiarkan berita seputar kesehatan dan tips tips kesehatan sehingga pasien mendapatkan informasi seputar kesehatan</p>
      </div>
    </div>
    <div class="item">
      <img src="img/parkiran.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>lapangan parkir yang luas</p>
        <p>lapangan parkir yang disediakan puskesmas tidak hanya cukup untuk motor tetapi juga mobil serta dilengkapi fasilitas gazebo untuk tempat menunggu pengantar pasien</p>
      </div>
    </div>
     <div class="item">
      <img src="img/pelayanan.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>pelayanan ramah</p>
        <p>pelayanan kami yang ramah membuat pasien merasa nyaman dan termotivasi untuk kembali sehat dan dapat menenangkan pasien selama masa perawatan</p>
      </div>
    </div>
    <div class="item">
      <img src="img/usg.png" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>fasilitas kehamilan</p>
        <p>pengecekkan kandungan sudah menggunakan USG 4 Dimensi yang sudah memungkinkan ibu hamil melihat kondisi bayinya secara jelas</p>
      </div>
    </div>
    <div class="item">
      <img src="img/masjid.jpg" alt="..." class="slide1">
      <div class="carousel-caption">
        <p>tempat ibadah</p>
        <p>Puskesmas Kita juga dilengkapi dengan mushola yang nyaman dan bersih, alat sholat yang rutin dibersihkan sehingga membuat pasien yang ingin beribadah jadi nyaman dan tidak khawatir dengan kebersihannya</p>
      </div>
    </div>
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

        <!--menu-->
          <div class="menu navbar navbar-inverse">
            <div class="container">
              <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
          </div>
          <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li><a href="index.php">HOME</a></li>
            <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">PROFILE</a>
          <ul class="dropdown-menu turun">
            <li><a class="tulis" href="visimisi.php">Visi-Misi</a></li>
            <li><a href="sambutan.php">Sambutan</a></li>
          </ul>
        </li>
            <li><a target="_blank" href="dokter.php">DATA DOKTER</a></li>
            <li><a target="_blank" href="pegawai.php">DATA PEGAWAI</a></li>
             <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">INFORMASI</a>
          <ul class="dropdown-menu turun">
            <li><a href="layanan.php" target="_blank">Pelayanan</a></li>
            <li><a href="agenda.php" target="_blank">Agenda</a></li>
          </ul>
        </li>
            </ul>
          </div>
          </div>
</div>
<!--end menu-->

<!--tanda-->
  <div>
    <table class="tanda">
      <tr>
        <td class="tanda2">Berita</td>
      </tr>
    </table>
  </div>
  <?php
        include ('konek.php');
        $sql = "SELECT id_berita,judul_berita, tanggal_upload, isi_berita FROM berita WHERE id_berita=6";
        $hasil = mysql_query($sql);
        $data = mysql_fetch_assoc($hasil);
      ?>
  <table class="tabel">
    <tr>
    <td class="judulnya">
    <?php
      echo $data['judul_berita'];
      ?>
    </td>
    </tr>
      <tr>
        <td class="gambarket">
          <img align="center" class="gambarket1" src="img/berita6.jpg" alt="image berita" >
        </td>
        </tr>
        <tr>
        <td class="keterangan">
          <?php
      echo "tanggal upload : ".$data['tanggal_upload']."<br><br/>";
      echo $data['isi_berita'];
      ?>
        </td>
      </tr>
    </table>

    <!--footer-->
    <div class="footer">
        <p>Ring Road Utara KM 10</br>
        Condong Catur, Sleman</br>
        D.I. Yogyakarta</br>
        (0274)446756/662819</p>
     </div>
 
  <!--Pemanggilan Java Script-->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.js"></script>
</body>
</html>